
<div class="main-slideshow owl-theme ">
                <a href=""><img src="{{asset('frontend/assets/images/slide3.jpg')}}" alt=""></a>
                <a href=""><img src="{{asset('frontend/assets/images/slide1.jpg')}}" alt=""></a>
                <a href=""><img src="{{asset('frontend/assets/images/slide2.jpg')}}" alt=""></a>
</div>