<?php $__env->startSection('title','Trang chủ'); ?>
<?php $__env->startSection('description','Destiantion'); ?>
<?php $__env->startSection('keywords','Destiantion'); ?>
<?php $__env->startSection('content'); ?>
<section class="tour">
            <div class="container">
                <div class="row breadcrumb-detail">
                 <ol class="breadcrumb">
                    <li><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                 
                    <li class="active"><?php echo e($dataDesti->name); ?></li>        
                  </ol>
                </div>
                <div class="tour-content">
                    <ul class="row">
                      <?php $__currentLoopData = $dataDestiTour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="col-xs-12 col-sm-6 col-md-3 item">
                            <div class="each-item">
                                <div class="image">
                                    <a href=""><img src="<?php echo e($tour->image); ?>" class="img-responsive" alt=""></a>
                                    <div class="address-tour">
                                        <span><i class="fa fa-map-marker"></i> <?php echo e($tour->provice_name); ?></span>
                                    </div>
                                </div>
                                <div class="info_product">
                                    <h3 class="name_pro"><a href="<?php echo e(URL::to('/')); ?>/tour-detail/<?php echo e($tour->id); ?>/<?php echo e($TourRepository->convert_vi_to_en($tour->name)); ?>.html" title="<?php echo e($tour->name); ?>">
                                     <?php $arrayDescription=explode(' ',$tour->name);
                                         $str="";
                                         $i=0;
                                        foreach($arrayDescription as $key => $value) {
                                         if($i<=10){
                                         $str.=$value." ";    
                                         }
                                         $i++;
                                        }
                                         echo trim($str,' ')."...";
                                         ?>
                                    </a></h3>
                                    <div class="price_pro">
                                        <b><?php if($tour->sale>0): ?>
                                         <span class="crossline"><?php echo e(number_format($tour->price)."đ"); ?></span> 
                                           <?php endif; ?>
                                         <?php echo e(number_format((int)($tour->price)*(1-(int)($tour->sale)/100))."đ"); ?>				
                                        </b>
                                    </div>
                                    <div class="datetime_pro"><i class="fa fa-calendar"></i> <?php echo e($TourRepository->subDate($tour->start_date,$tour->end_date)); ?> | Phương tiện: <?php echo $tour->traffic_name; ?></div>
                                    <!-- <div class="starttour">KH: </div> -->
                                    <div class="address_pro">
                                        <span><i class="fa fa-calendar-check-o"></i> Khởi hành <?php echo e(date('d-m-Y', strtotime($tour->start_date))); ?></span>
                                    </div>
                                    <div class="addtocartdiv">
                                        <a href="<?php echo e(URL::to('/')); ?>/checkout/<?php echo e($tour->id); ?>" class="add-tour">Đặt tour</a>
                                        <a href="<?php echo e(URL::to('/')); ?>/tour-detail/<?php echo e($tour->id); ?>/<?php echo e($TourRepository->convert_vi_to_en($tour->name)); ?>.html" class="tour-detail">Xem chi tiết</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="text-center">
                    <?php echo e($dataDestiTour->links()); ?>

                </div>
               
            </div>
        </section>
     <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>