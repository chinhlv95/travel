
<div class="main-menu">
                <div class="container">
                    <nav class="navbar navbar-default" role="navigation">
                        <div class="container-fluid">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>">TRANG CHỦ</a>
                            </div>
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse navbar-ex1-collapse">
                                <ul class="nav navbar-nav">
                                    <?php $__currentLoopData = $dataCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <li><a href="<?php echo e(URL::to('/')); ?>/category/<?php echo e($value['id']); ?>/<?php echo e($CategoryRepository->convert_vi_to_en($value['name'])); ?>.html" title="<?php echo e($value['name']); ?>"><?php echo e($value['name']); ?></a>
                                         </li>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    
                                 
                                    <li><a href="#">CẨM NANG DU LỊCH</a></li>
                                    <li><a href="#">LIÊN HỆ</a></li>
                                </ul>
                                <ul class="nav navbar-nav navbar-right">
                                    <div class="mainmenu_support">
                                        <span><i class="fa fa-phone"></i> Tư vấn miễn phí</span>
                                        <div>01665.431.893 - 0123.456.789</div>
                                    </div>
                                </ul>
                            </div>
                            <!-- /.navbar-collapse -->
                        </div>
                    </nav>
                </div>
            </div>