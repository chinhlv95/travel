<?php $__env->startSection('title'); ?>
<?php echo e($dataTour->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?>
<?php echo e($dataTour->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?>
<?php echo e($TourRepository->convert_vi_to_en($dataTour->name)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="detail-tour">
         <div class="container">
             <div class="row breadcrumb-detail">
                 <ol class="breadcrumb">
                    <li><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                    <li ><a href="<?php echo e(url('/tours')); ?>">Tour</a></li>
                    <li class="active"><?php echo e($dataTour->name); ?></li>        
                  </ol>
             </div>
        
         <div class="tour-content">
             <div class="row">
                 <div class="col-md-5">
                     <div class="image-top">
                         <img id="img-first-detail" src="<?php echo e($dataTour->image); ?>" alt="<?php echo e($dataTour->image); ?>">
                     </div> 
                     <div class="tour-detail-img owl-theme">
                    <?php $__currentLoopData = $TourRepository->imageTour($dataTour->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $imageTour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="slide">
                       <img   class="img-slide-detail"src="<?php echo e($imageTour->name); ?>" alt="<?php echo e($imageTour->name); ?>">
                     </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                     </div>
                 </div>
                 <div class="col-md-7">
                     <div class="right-tour-detail">
                         <h1><?php echo e($dataTour->name); ?></h1>

                         <h3>Hành trình: <?php echo e($dataTour->journey); ?></h3>
                         <div class="socail-fb">
                            
                         </div>
                         <div class="sapo-tour">
                            <?php $arrayDescription=explode(' ',$dataTour->description );
                             $str="";
                             $i=0;
                            foreach($arrayDescription as $key => $value) {
                             if($i<=90){
                             $str.=$value." ";    
                             }
                             $i++;
                             }
                             echo trim($str,' ')."...";
                             ?>
                            
                         </div>
                         <div class="add-tour-detail">
                             <div class="row">
                                 <div class="col-md-6">
                                     <div class="add-tour-left">
                                         <span>Khởi hành:<a href=""><?php echo e($dataTour->provice_name); ?></a></span>
                                         <p>Thời gian:<?php echo e($TourRepository->subDate($dataTour->start_date,$dataTour->end_date)); ?></p>
                                         <p>Thời gian khởi hành:<?php echo e(date('d-m-Y', strtotime($dataTour->start_date))); ?></p>
                                         <p>
                                         <?php if(((int)($dataTour->quantity)-(int)($dataTour->booked))>0): ?>
                                          <?php echo e("Còn:".((int)($dataTour->quantity)-(int)($dataTour->booked))." chỗ"); ?>

                                         <?php else: ?>
                                         <?php echo e("Hết chỗ"); ?>

                                         <?php endif; ?>
                                         </p>
                                     </div>
                                 </div>
                                 <div class="col-md-6">
                                     <div class="add-tour-right">
                                     <?php if($dataTour->sale>0): ?>
                                         <p><span id="money-unline"><?php echo e(number_format($dataTour->price)."đ"); ?></span></p>
                                         <p><span>Giá từ:</span><span id="tour-money">
                                              <?php echo e(number_format((int)($dataTour->price)*(1-(int)($dataTour->sale)/100))."đ"); ?>     
                                         </span></p>
                                         <?php else: ?>
                                            <p><span>Giá từ:</span><span id="tour-money"><?php echo e(number_format($dataTour->price)); ?></span></p>
                                         <?php endif; ?>
                                          <?php if(((int)($dataTour->quantity)-(int)($dataTour->booked))>0): ?>
                                          <div class="add-tour-order">
                                             <a href="<?php echo e(URL::to('/')); ?>/checkout/<?php echo e($dataTour->id); ?>" title="">Đặt tour</a>
                                         </div>                                         
                                         <?php else: ?>
                                         <div class="add-tour-order">
                                             <a href="javascript:void(0)" title="">Hết chỗ</a>
                                         </div>
                                         <?php endif; ?>
                                         
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <div class="description-tour">
             <div class="row">
                 <div class="col-md-8">
                     <div class="description-tour-left">
                         <ul class="nav nav-tabs">
                          <li class="active"><a data-toggle="tab" href="#home">Tổng quan</a></li>
                          <li><a data-toggle="tab" href="#menu1">Lịch trình</a></li>
                          <li><a data-toggle="tab" href="#menu2">Ghi chú</a></li>
                        </ul>

                        <div class="tab-content">
                          <div id="home" class="tab-pane fade in active">
                    
                            <p><?php echo $dataTour->description; ?></p>
                          </div>
                          <div id="menu1" class="tab-pane fade">
                          
                            <p><?php echo $dataTour->content; ?></p>
                          </div>
                          <div id="menu2" class="tab-pane fade">
                          
                            <p><?php echo $dataTour->note; ?></p>
                          </div>
                        </div>
                     </div>
                 </div>
                 <div class="col-md-4">
                     <div class="description-tour-right">
                         <div class="title-tour-relation">
                             <h3><i class="fa fa-filter"></i> Tour liên quan</h3>
                         </div>

                         <div class="list-tour-relation">
                             <ul>
                            <?php $__currentLoopData = $TourRepository->relationTour($dataTour->destination_id,$dataTour->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 
                            
                                 <li>
                                     <a href="<?php echo e(URL::to('/')); ?>/tour-detail/<?php echo e($relation->id); ?>/<?php echo e($TourRepository->convert_vi_to_en($relation->name)); ?>.html">
                                         <div class="box-relation">
                                             <div class="box-relation-img">
                                                 <img src="<?php echo e($relation->image); ?>" alt="">
                                             </div>
                                             <div class="box-relation-info">
                                                 <p><?php echo e($relation->name); ?></p>
                                                 <p>
                                                     <span class="start-tour">Khởi hành: <?php echo e(date('d/m/Y', strtotime($relation->start_date))); ?> </span>
                                                     <span class="discount">
                                                         <?php echo e(number_format((int)($relation->price)*(1-(int)($relation->sale)/100))."đ"); ?>     
                                                     </span>
                                                 </p>
                                             </div>
                                         </div>
                                     </a>
                                   
                                 </li>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                             </ul>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <div class="tour-sale">
             <div class="tour-sale-title">
                 <h2><a href="">Tour giảm giá</a></h2>
                 <p class="tour-sale-line"></p>
             </div>

             <ul class="row">
               <?php $__currentLoopData = $dataTourSale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $saleTour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                 <li class="col-md-3"><a href="<?php echo e(URL::to('/')); ?>/tour-detail/<?php echo e($saleTour->id); ?>/<?php echo e($TourRepository->convert_vi_to_en($saleTour->name)); ?>.html">
                     <div class="box-sale">
                         <img src="<?php echo $saleTour->image; ?>" alt="">
                          <div class="box-sale-info">
                          <p><a href="<?php echo e(URL::to('/')); ?>/tour-detail/<?php echo e($saleTour->id); ?>/<?php echo e($TourRepository->convert_vi_to_en($saleTour->name)); ?>.html"><?php echo e($saleTour->name); ?></a></p>
                         <p>
                             <span>Giá từ:</span>
                             <?php if($saleTour->sale>0): ?>
                             <span class="price-sale"> 
                             <?php echo e(number_format((int)($saleTour->price)*(1-(int)($saleTour->sale)/100))."đ"); ?>     
                             </span>
                             <span class="price-not-sale">
                             <?php echo e(number_format((int)($saleTour->price))."đ"); ?>     
                              </span>
                             <?php else: ?>
                               <span class="price-sale"> 
                             <?php echo e(number_format((int)($saleTour->price))."đ"); ?>     
                             </span>
                             <?php endif; ?>
                         </p>
                     </div>
                     </div>
                 </a></li>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                 
             </ul>
         </div>
         <div class="tour-sale">
             <div class="tour-sale-title">
                 <h2><a href="">Tour Cùng Ngày</a></h2>
                 <p class="tour-sale-line"></p>
             </div>
             <?php 
               $dataTourDate=$TourRepository->sameStartDate($dataTour->start_date,$dataTour->id);
              ?>
             <ul class="row">
               <?php $__currentLoopData = $dataTourDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sameTourDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                 <li class="col-md-3"><a href="<?php echo e(URL::to('/')); ?>/tour-detail/<?php echo e($sameTourDate->id); ?>/<?php echo e($TourRepository->convert_vi_to_en($sameTourDate->name)); ?>.html">
                     <div class="box-sale">
                         <img src="<?php echo $sameTourDate->image; ?>" alt="">
                          <div class="box-sale-info">
                          <p><a href="<?php echo e(URL::to('/')); ?>/tour-detail/<?php echo e($sameTourDate->id); ?>/<?php echo e($TourRepository->convert_vi_to_en($sameTourDate->name)); ?>.html"><?php echo e($sameTourDate->name); ?></a></p>
                         <p>
                             <span>Giá từ:</span>
                             <?php if($sameTourDate->sale>0): ?>
                             <span class="price-sale"> 
                             <?php echo e(number_format((int)($sameTourDate->price)*(1-(int)($sameTourDate->sale)/100))."đ"); ?>     
                             </span>
                             <span class="price-not-sale">
                             <?php echo e(number_format((int)($sameTourDate->price))."đ"); ?>     
                              </span>
                             <?php else: ?>
                               <span class="price-sale"> 
                             <?php echo e(number_format((int)($sameTourDate->price))."đ"); ?>     
                             </span>
                             <?php endif; ?>
                         </p>
                     </div>
                     </div>
                 </a></li>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                 
             </ul>
         </div>
          </div>
    
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>