<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tour
                    <small>Edit</small>
                </h1>
            </div>
            <div class="col-lg-12">
                <div class="alert alert-success alert-show">
                    
                </div>
            </div>
            <!-- /.col-lg-12 -->
            <div class="col-lg-12" style="padding-bottom:120px">
                <form action="admin/tour/edit/<?php echo e($tour->id); ?>" method="POST">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <div class="col-lg-9">
                        <div class="form-group">
                            <label>Tour Name:* <span id="error-name" class="errors">
                            <?php if($errors->has('name')): ?>
                            <?php echo e($errors->first('name')); ?>

                            <?php endif; ?>
                            </span></label>
                            <input type="text" value="<?php echo e(old('name',$tour->name)); ?>" class="form-control" name="name" placeholder="Please Enter Tour Name" />
                        </div>
                        <div class="form-group">
                            <label>Journey:* <span id="error-journey" class="errors">
                            <?php if($errors->has('journey')): ?>
                            <?php echo e($errors->first('journey')); ?>

                            <?php endif; ?>
                            </span></label>
                            <input type="text" value="<?php echo e(old('journey',$tour->journey)); ?>" class="form-control" name="journey" placeholder="Please Enter Journey" />
                        </div>
                        <div class="form-group">
                            <label>Content:* <span id="error-content" class="errors">
                            <?php if($errors->has('content')): ?>
                            <?php echo e($errors->first('content')); ?>

                            <?php endif; ?>
                            </span></label>
                            <textarea class="tinymce" name="content"><?php echo e(old('content',$tour->content)); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Description:* <span id="error-description" class="errors">
                            <?php if($errors->has('description')): ?>
                            <?php echo e($errors->first('description')); ?>

                            <?php endif; ?>
                            </span></label>
                            <textarea class="tinymce" name="description"><?php echo e(old('description',$tour->description)); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Note: <span id="error-note" class="errors"></span></label>
                            <textarea class="tinymce" name="note"><?php echo e(old('note',$tour->note)); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Quantity:* <span id="error-quantity" class="errors">
                            <?php if($errors->has('quantity')): ?>
                            <?php echo e($errors->first('quantity')); ?>

                            <?php endif; ?>
                            </span></label>
                            <input type="number" class="form-control" name="quantity" placeholder="Please Enter Quantity" value="<?php echo e(old('quantity',$tour->quantity)); ?>" />
                        </div>
                        <div class="form-group">
                            <label>Booked: <span id="error-quantity" class="errors"></span></label>
                            <input type="number" class="form-control" name="booked" value="<?php echo e(old('booked',$tour->booked)); ?>"/>
                        </div>
                        <div class="form-group">
                            <label>Image:* <span id="error-image" class="errors">
                            <?php if($errors->has('image')): ?>
                            <?php echo e($errors->first('image')); ?>

                            <?php endif; ?>
                            </span></label>
                            <div><img id="image" width="150px" height="100px" src="<?php echo e($tour->image); ?>" ></div>
                            <input type="text" class="form-control" id="image-tour" name="image" placeholder="Please Insert Tour Image" value="<?php echo e(old('image',$tour->image)); ?>" />
                        </div>
                        <div class="form-group">
                            <label>Price(VND):* <span id="error-price" class="errors">
                            <?php if($errors->has('price')): ?>
                            <?php echo e($errors->first('price')); ?>

                            <?php endif; ?>
                            </span></label>
                            <input type="number" class="form-control" name="price" placeholder="Please Enter Price" value="<?php echo e(old('price',$tour->price)); ?>" />
                        </div>
                        <div class="form-group">
                            <label>Sale(%): <span id="error-sale" class="errors"></span></label>
                            <select class="form-control" name="sale_id">
                                <?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sale->id); ?>" 
                                    <?php if($sale->id == $tour->sale_id): ?>
                                    <?php echo e("selected"); ?>

                                    <?php endif; ?>
                                    <?php echo e((old("sale_id") == $tour->sale_id ? "selected":"")); ?>>
                                    <?php echo e($sale->sale_precent); ?>%</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Province: <span id="error-province" class="errors"></span></label>
                            <select class="form-control" name="province_id">
                                <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($province->id); ?>"
                                    <?php if($province->id == $tour->province_id): ?>
                                    <?php echo e("selected"); ?>

                                    <?php endif; ?>
                                    <?php echo e((old("province_id") == $tour->province_id ? "selected":"")); ?>>
                                    <?php echo e($province->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Destination: <span id="error-destination" class="errors"></span></label>
                            <select class="form-control" name="destination_id">
                                <?php $__currentLoopData = $desti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($desti->id); ?>"
                                    <?php if($desti->id == $tour->destination_id): ?>
                                    <?php echo e("selected"); ?>

                                    <?php endif; ?>
                                    <?php echo e((old("destination_id") == $tour->destination_id ? "selected":"")); ?>>
                                    <?php echo e($desti->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Traffic: <span id="error-traffic" class="errors"></span></label>
                            <select class="form-control" name="traffic_id">
                                <?php $__currentLoopData = $traffic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traffic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($traffic->id); ?>"
                                    <?php if($traffic->id == $tour->traffic_id): ?>
                                    <?php echo e("selected"); ?>

                                    <?php endif; ?>
                                    <?php echo e((old("traffic_id") == $tour->traffic_id ? "selected":"")); ?>>
                                    <?php echo $traffic->name; ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Start Date:* <span id="error-start_date" class="errors"></span></label>
                            <input type="date" class="form-control" name="start_date" value="<?php echo e(old('start_date',$tour->start_date)); ?>"/>
                        </div>
                        <div class="form-group">
                            <label>End Date:* <span id="error-end_date" class="errors"></span></label>
                            <input type="date" class="form-control" name="end_date" value="<?php echo e(old('end_date',($tour->end_date != "")?$tour->end_date:"")); ?>" />
                        </div>
                        <div class="form-group">
                            <label>Status: </label> <br>
                            <label class="radio-inline">
                                <input name="status" value="0"
                                <?php if($tour->status == 0): ?>
                                    <?php echo e("checked"); ?>

                                <?php endif; ?>
                                <?php echo e((old("status") == 0 ? "checked":"")); ?>

                                type="radio">Private
                            </label>
                            <label class="radio-inline">
                                <input name="status" value="1" 
                                <?php if($tour->status == 1): ?>
                                    <?php echo e("checked"); ?>

                                <?php endif; ?>
                                <?php echo e((old("status") == 1 ? "checked":"")); ?>

                                type="radio">Published
                            </label>
                        </div>
                        <div class="form-group">
                            <label>Hot: </label> <br>
                            <label class="radio-inline">
                                <input name="is_hot" value="0"
                                <?php if($tour->is_hot == 0): ?>
                                    <?php echo e("checked"); ?>

                                <?php endif; ?>
                                <?php echo e((old("is_hot") == 0 ? "checked":"")); ?>

                                type="radio">Not Hot
                            </label>
                            <label class="radio-inline">
                                <input name="is_hot" value="1"
                                <?php if($tour->is_hot == 1): ?>
                                    <?php echo e("checked"); ?>

                                <?php endif; ?>
                                <?php echo e((old("is_hot") == 1 ? "checked":"")); ?>

                                type="radio">Hot
                            </label>
                        </div>
                        <div class="form-group">
                            <label>Meta Key: <span id="error-meta_key" class="errors"></span></label>
                            <input type="text" class="form-control" name="meta_key" value="<?php echo e(old('meta_key',$tour->meta_key)); ?>" placeholder="Please Enter Meta Key" />
                        </div>
                        <div class="form-group">
                            <label>Name Seo: <span id="error-name_seo" class="errors"></span></label>
                            <input type="text" class="form-control" name="name_seo"
                            value="<?php echo e(old('name_seo',$tour->name_seo)); ?>" placeholder="Please Enter Name Seo" />
                        </div>
                        <div class="form-group">
                            <label>Tag: <span id="error-tag" class="errors"></span></label>
                            <input type="text" class="form-control" name="tag" value="<?php echo e(old('tag',$tour->tag)); ?>" placeholder="Please Enter Tag" />
                        </div>
                        <div class="form-group">
                            <input type="hidden" class="form-control" name="user_id" value="<?php echo e(Auth::user()->id); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div><h3>Image Gallery</h3></div>
                        <div class="form-group">
                            <input type="hidden" id="hidden-tour" name="image-hidden">
                        </div>
                        <?php $__currentLoopData = $tour_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="show-image-edit">
                            <img title="" width="150px" height="100px" src="<?php echo e($tour_image->name); ?>" >
                            <a href="javascript:void(0)" data-id="<?php echo e($tour_image->id); ?>" class="btn-danger btn-circle remove_field del-image"><i class="fa fa-times" aria-hidden="true"></i></a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div id="custom-div"></div>
                        <button type="button" class="btn btn-info btn-sm add_image_field"><i class="fa fa-plus-circle" aria-hidden="true"></i> ADD</button>
                    </div>
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-default">Edit Tour</button>
                        <a href="admin/tour/list" class="btn btn-default" title="">Back</a>
                    </div>
                <form>
                <div class="modal fade" id="modal-tour" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content" style="width: 900px;">
                        <div class="modal-header">
                           <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                          <h4 class="modal-title" id="myModalLabel">Tour Image</h4>
                        </div>
                        <div class="modal-body">
                           <iframe  width="100%" height="550" frameborder="0" src="<?php echo e(URL::to('/')); ?>/filemanager/dialog.php?type=1&field_id=image-tour">
                          </iframe>
                        </div>
                      </div>
                    </div>
                </div>
                <div class="modal fade" id="imagetour" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content" style="width: 900px;">
                        <div class="modal-header">
                           <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                          <h4 class="modal-title" id="myModalLabel">Tour Image</h4>
                        </div>
                        <div class="modal-body">
                           <iframe  width="100%" height="550" frameborder="0" src="<?php echo e(URL::to('/')); ?>/filemanager/dialog.php?type=1&field_id=hidden-tour">
                          </iframe>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>