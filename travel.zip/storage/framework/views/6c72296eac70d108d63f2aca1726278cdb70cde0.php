<?php $__env->startSection('title','Trang chủ'); ?>
<?php $__env->startSection('description'); ?>
<?php echo e('Trang chủ'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?>
<?php echo e('Trang chủ'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="filter-gobal">
	<div class="container">
		<div class="row breadcrumb-detail">
         <ol class="breadcrumb">
            <li><a href="#">Home</a></li>
            <li class="active">Tìm tour</li>        
          </ol>
        </div>
        <div class="content-search-tour">
        	<table class="table table-bordered table-hover">
        		<thead>
        			<tr>
        				<th>Mã Tour</th>
        				<th>Điểm đến</th>
        				<th>Số Ngày</th>
        				<th>Ngày đi</th>
        				<th>Ngày về</th>
        				<th>Giá</th>
        				<th>Số chỗ còn nhận</th>
        				<th>Book</th>
        			</tr>
        		</thead>
        		<tbody>

        		<?php $__currentLoopData = $dataFilterTour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php 
                      $dataSaleFilter=$SaleRepository->find($value->sale_id);
                      ?>
        			 <tr>
        				<td><?php echo e($value->id); ?></td>
        				<td><a href="<?php echo e(URL::to('/')); ?>/tour-detail/<?php echo e($value->id); ?>/<?php echo e($SaleRepository->convert_vi_to_en($value->name)); ?>.html" title="<?php echo e($value->name); ?>"><?php echo e($value->name); ?></a></td>
        				<td class="date-tour"><?php echo e($TourRepository->subDate($value->start_date,$value->end_date)); ?></td>
        				<td class="date-tour"><?php echo e(date('d-m-Y', strtotime($value->start_date))); ?></td>
        				<td class="date-tour" ><?php echo e(date('d-m-Y', strtotime($value->end_date))); ?></td>
        				<td> <?php echo e(number_format((int)($value->price)*(1-(int)($dataSaleFilter->sale_precent)/100))."đ"); ?> </td>
        				<td><?php echo e(((int)($value->quantity)-(int)($value->booked))); ?></td>
        				<td>
                         <?php if(((int)($value->quantity)-(int)($value->booked))==0): ?>
                         <div class="contact">
                             <a href="#">Liên hệ</a>
                         </div>
                         <?php else: ?>
                          <div class="add-tour">
                             <a href="<?php echo e(URL::to('/')); ?>/checkout/<?php echo e($value->id); ?>">Đặt tour</a>
                         </div>
                         <?php endif; ?>            
                        </td>
        			</tr>
        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</tbody>
        	</table>
        	<div id="pagination-filter">
               <?php echo e($dataFilterTour->links()); ?>  
        	</div>
        </div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>