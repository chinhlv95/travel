<div class="heading1 ">
    <div class="dropdown">
        <div class="oder" data-toggle="dropdown">Categories
        <span class="caret"></span></div>
        <ul class="dropdown-menu">
        <li><a href="admin/tour/list">All</a></li>
        <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="admin/tour/category/<?php echo e($cate->id); ?>" id="<?php echo e($cate->id); ?>"> <?php echo e($cate->name); ?> </a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="dropdown">
        <div class="oder" data-toggle="dropdown">Provinces
        <span class="caret"></span></div>
        <ul class="dropdown-menu">
        <li><a href="admin/tour/list">All</a></li>
        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="admin/tour/province/<?php echo e($province->id); ?>" id="<?php echo e($province->id); ?>"><?php echo e($province->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="dropdown">
        <div class="oder" data-toggle="dropdown">Destinations
        <span class="caret"></span></div>
        <ul class="dropdown-menu">
        <li><a href="admin/tour/list">All</a></li>
        <?php $__currentLoopData = $destis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="admin/tour/destination/<?php echo e($desti->id); ?>" id="<?php echo e($desti->id); ?>"><?php echo e($desti->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>