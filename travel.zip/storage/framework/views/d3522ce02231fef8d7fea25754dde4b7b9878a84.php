<div class="container">
                <div class="filter">
                    <div class="title-filter">
                        <h3><span class="glyphicon glyphicon-search"></span> Tìm Tour</h3>
                    </div>
                    <div class="filter-content">
                        <form class="form-inline" action="<?php echo e(URL::to('/')); ?>/filter" method="get">
                           
                            <div class="form-group">
                                <select class="selectpicker" data-size="3" id="cat-tour" data-live-search="true" name="cate">
                                    <option value="" >-Chọn tuyến-</option>
                                     <?php $__currentLoopData = $dataCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option  value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                              <div class="form-group">
                                <select class="selectpicker" data-size="4" data-live-search="true" name="province">
                                    <option value=""  data-icon="glyphicon-map-marker">Điểm Khởi hành</option>
                                   <?php $__currentLoopData = $dataProvince; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option  value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="selectpicker" data-size="4" id="destination-tour" data-live-search="true" name="destination">
                                    <option  value="" data-icon="glyphicon-map-marker">Điểm đến</option>
                                     <?php $__currentLoopData = $dataDestination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option  value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control start-date" placeholder="Ngày khởi hành" value="<?php echo e(old('start')); ?>" data-toggle="tooltip" title="Ngày khởi đầu" name="start">
                            </div>
                            <div class="form-group">
                                <select class="selectpicker" data-size="4" data-live-search="true" name="price">
                                    <option value=""  data-icon="glyphicon-usd">Chọn giá tour</option>
                                      <?php $__currentLoopData = $dataPriceRange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option  value="<?php echo e($value['from_price']."-".$value['to_price']); ?>"><?php echo e($value['from_price']."-".$value['to_price']."(đ)"); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                </select>
                            </div>
                            <button type="submit" class="btn btn-default search">Tìm Kiếm</button>
                        </form>
                    </div>
                </div>
            </div>