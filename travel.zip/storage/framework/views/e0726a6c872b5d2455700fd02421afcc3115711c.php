<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tour
                    <small>Add</small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->
            <div class="col-lg-12" style="padding-bottom:120px">
                <form action="admin/tour/add" method="POST">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <div class="col-lg-9">
                        <div class="form-group">
                            <label>Tour Name:* <span id="error-name" class="errors">
                            <?php if($errors->has('name')): ?>
                            <?php echo e($errors->first('name')); ?>

                            <?php endif; ?>
                            </span></label>
                            <input value="<?php echo e(old('name')); ?>" class="form-control" name="name" placeholder="Please Enter Tour Name" />
                        </div>
                        <div class="form-group">
                            <label>Journey:* <span id="error-journey" class="errors">
                            <?php if($errors->has('journey')): ?>
                            <?php echo e($errors->first('journey')); ?>

                            <?php endif; ?>
                            </span></label>
                            <input value="<?php echo e(old('journey')); ?>" class="form-control" name="journey" placeholder="Please Enter Journey" />
                        </div>
                        <div class="form-group">
                            <label>Content:* <span id="error-content" class="errors">
                            <?php if($errors->has('content')): ?>
                            <?php echo e($errors->first('content')); ?>

                            <?php endif; ?>
                            </span></label>
                            <textarea class="tinymce" name="content"><?php echo e(old('content')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Description:* <span id="error-description" class="errors">
                            <?php if($errors->has('description')): ?>
                            <?php echo e($errors->first('description')); ?>

                            <?php endif; ?>
                            </span></label>
                            <textarea class="tinymce" name="description"><?php echo e(old('description')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Note: <span id="error-note" class="errors"></span></label>
                            <textarea class="tinymce" name="note"><?php echo e(old('note')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Quantity:* <span id="error-quantity" class="errors">
                            <?php if($errors->has('quantity')): ?>
                            <?php echo e($errors->first('quantity')); ?>

                            <?php endif; ?>
                            </span></label>
                            <input type="number" value="<?php echo e(old('quantity')); ?>" class="form-control" name="quantity" placeholder="Please Enter Quantity" />
                        </div>
                        <div class="form-group">
                            <input type="hidden" class="form-control" name="booked" value="0"/>
                        </div>
                        <div class="form-group">
                            <label>Image:* <span id="error-image" class="errors">
                            <?php if($errors->has('image')): ?>
                            <?php echo e($errors->first('image')); ?>

                            <?php endif; ?>
                            </span></label>
                            <div><img id="image" 
                            <?php if(old('image') != ""): ?>
                            width="150px" height="100px"
                            <?php endif; ?>
                            src="<?php echo e(old('image')); ?>" ></div>
                            <input type="text" value="<?php echo e(old('image')); ?>" class="form-control" id="image-tour" name="image" placeholder="Please Insert Tour Image" />
                        </div>
                        <div class="form-group">
                            <label>Price(VND):* <span id="error-price" class="errors">
                            <?php if($errors->has('price')): ?>
                            <?php echo e($errors->first('price')); ?>

                            <?php endif; ?>
                            </span></label>
                            <input type="number" value="<?php echo e(old('price')); ?>" class="form-control" name="price" placeholder="Please Enter Price" />
                        </div>
                        <div class="form-group">
                            <label>Sale(%): <span id="error-sale" class="errors"></span></label>
                            <select class="form-control" name="sale_id">
                                <?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sale->id); ?>"
                                    <?php echo e((old("sale_id") == $sale->id ? "selected":"")); ?>

                                    ><?php echo e($sale->sale_precent); ?>%</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Province: <span id="error-province" class="errors"></span></label>
                            <select class="form-control" name="province_id">
                                <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($province->id); ?>"
                                    <?php echo e((old("province_id") == $province->id ? "selected":"")); ?>

                                    ><?php echo e($province->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Destination: <span id="error-destination" class="errors"></span></label>
                            <select class="form-control" name="destination_id">
                                <?php $__currentLoopData = $desti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($desti->id); ?>"
                                    <?php echo e((old("destination_id") == $desti->id ? "selected":"")); ?>

                                    ><?php echo e($desti->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Traffic: <span id="error-traffic" class="errors"></span></label>
                            <select class="form-control" name="traffic_id">
                                <?php $__currentLoopData = $traffic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $traffic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($traffic->id); ?>"
                                    <?php echo e((old("traffic_id") == $traffic->id ? "selected":"")); ?>

                                    ><?php echo $traffic->name; ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Start Date:* <span id="error-start_date" class="errors">
                            <?php if($errors->has('start_date')): ?>
                            <?php echo e($errors->first('start_date')); ?>

                            <?php endif; ?>
                            </span></label>
                            <input type="date" value="<?php echo e(old('start_date')); ?>" class="form-control" name="start_date" />
                        </div>
                        <div class="form-group">
                            <label>End Date:* <span id="error-end_date" class="errors">
                            <?php if($errors->has('end_date')): ?>
                            <?php echo e($errors->first('end_date')); ?>

                            <?php endif; ?>
                            </span></label>
                            <input type="date" value="<?php echo e(old('end_date')); ?>" class="form-control" name="end_date" />
                        </div>
                        <div class="form-group">
                            <label>Status: </label> <br>
                            <label class="radio-inline">
                                <input name="status" value="0" checked
                                <?php echo e((old("status") == 0 ? "checked":"")); ?>

                                type="radio">Private
                            </label>
                            <label class="radio-inline">
                                <input name="status" value="1"
                                <?php echo e((old("status") == 1 ? "checked":"")); ?> 
                                type="radio">Published
                            </label>
                        </div>
                        <div class="form-group">
                            <label>Hot: </label> <br>
                            <label class="radio-inline">
                                <input name="is_hot" value="0" checked
                                <?php echo e((old("is_hot") == 0 ? "checked":"")); ?>

                                type="radio">Not Hot
                            </label>
                            <label class="radio-inline">
                                <input name="is_hot" value="1"
                                <?php echo e((old("is_hot") == 1 ? "checked":"")); ?>

                                type="radio">Hot
                            </label>
                        </div>
                        <div class="form-group">
                            <label>Meta Key: <span id="error-meta_key" class="errors"></span></label>
                            <input type="text" value="<?php echo e(old('meta_key')); ?>" class="form-control" name="meta_key" placeholder="Please Enter Meta Key" />
                        </div>
                        <div class="form-group">
                            <label>Name Seo: <span id="error-name_seo" class="errors"></span></label>
                            <input type="text" value="<?php echo e(old('name_seo')); ?>" class="form-control" name="name_seo" placeholder="Please Enter Name Seo" />
                        </div>
                        <div class="form-group">
                            <label>Tag: <span id="error-tag" class="errors"></span></label>
                            <input type="text" value="<?php echo e(old('tag')); ?>" class="form-control" name="tag" placeholder="Please Enter Tag" />
                        </div>
                        <div class="form-group">
                            <input type="hidden" class="form-control" name="user_id" value="<?php echo e(Auth::user()->id); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div><h3>Image Gallery</h3></div>
                        <div class="form-group">
                            <input type="hidden" id="hidden-tour" name="image-hidden">
                        </div>
                        <div class="form-group">
                            <img id="image_0" src="" >
                            <input type="text" placeholder="Inser image" count="0" id="imagetour_0" value="" class="form-control imagepro" name="imagepro[]"/>
                            <a href="#" class="btn-danger btn-circle icon_del remove_field"><i class="fa fa-times" aria-hidden="true"></i></a>
                        </div>
                        <div id="custom-div"></div>
                        <button type="button" class="btn btn-info btn-sm add_image_field"><i class="fa fa-plus-circle" aria-hidden="true"></i> ADD</button>
                    </div>
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-default">Add Tour</button>
                        <a href="admin/tour/list" class="btn btn-default" title="">Back</a>
                    </div>
                <form>
                <div class="modal fade" id="modal-tour" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content" style="width: 900px;">
                        <div class="modal-header">
                           <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                          <h4 class="modal-title" id="myModalLabel">Tour Image</h4>
                        </div>
                        <div class="modal-body">
                           <iframe  width="100%" height="550" frameborder="0" src="<?php echo e(URL::to('/')); ?>/filemanager/dialog.php?type=1&field_id=image-tour">
                          </iframe>
                        </div>
                      </div>
                    </div>
                </div>
                <div class="modal fade" id="imagetour" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content" style="width: 900px;">
                        <div class="modal-header">
                           <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                          <h4 class="modal-title" id="myModalLabel">Tour Image</h4>
                        </div>
                        <div class="modal-body">
                           <iframe  width="100%" height="550" frameborder="0" src="<?php echo e(URL::to('/')); ?>/filemanager/dialog.php?type=1&field_id=hidden-tour">
                          </iframe>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>