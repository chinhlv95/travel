<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<div id="page-wrapper" class="tour-detail">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Tour
                    <small>Detail</small>
                </h1>
            </div>
            <!-- /.col-lg-12 -->    
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h1 class="modal-title">Tour
                        <small>Detail</small></h1>
                    </div>
                    <div class="modal-body">
                        <ul class="nav nav-tabs nav-justified">
                        <li class="active"><a data-toggle="tab" href="#tour">Tour Detail</a></li>
                        <li><a data-toggle="tab" href="#more">More</a></li>
                        </ul>
                        <div class="tab-content">
                            <div id="tour" class="tab-pane fade in active">
                                <h3 class="head">Tour Name:</h3>
                                <div><?php echo e($tour->name); ?></div>
                                <h3 class="head">Journey:</h3>
                                <div><?php echo $tour->journey; ?></div>
                                <h3 class="head">Content:</h3>
                                <div><?php echo $tour->content; ?></div>
                                <h3 class="head">Description:</h3>
                                <div><?php echo $tour->description; ?></div>
                                <h3 class="head">Note:</h3>
                                <div><?php echo $tour->note; ?></div>
                                <h3 class="head">Quantity:</h3>
                                <div><?php echo e($tour->quantity); ?> People</div>
                                <h3 class="head">Booked:</h3>
                                <div><?php echo e($tour->booked); ?> People</div>
                                <h3 class="head">Image:</h3>
                                <div><img width="30%" src="<?php echo e($tour->image); ?>" alt="" title=""></div>
                                <h3 class="head">More Image:</h3>
                                <div>
                                <?php $__currentLoopData = $tour_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img width="150px" height="100px" style="margin-right: 10px" src="<?php echo e($tour_image->name); ?>" alt="" title="">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <h3 class="head">Price:</h3>
                                <div><?php echo e(number_format($tour->price, 0 , ",", "." )); ?> VND</div>
                                <h3 class="head">Sale:</h3>
                                <div><?php echo e($tour->sale->sale_precent); ?>%</div>
                                <h3 class="head">Province:</h3>
                                <div><?php echo e($tour->province->name); ?></div>
                                <h3 class="head">Destination:</h3>
                                <div><?php echo e($tour->destination->name); ?></div>
                                <h3 class="head">Traffic:</h3>
                                <div><?php echo $tour->traffic->name; ?></div>
                                <h3 class="head">Start Date:</h3>
                                <div><?php echo e(date('d-m-Y', strtotime($tour->start_date))); ?></div>
                                <h3 class="head">End Date:</h3>
                                <div><?php echo e(date('d-m-Y', strtotime($tour->end_date))); ?></div>
                            </div>
                            <div id="more" class="tab-pane fade">
                                <h3 class="head">Status:</h3>
                                <div>
                                    <?php if($tour->status == 0): ?>
                                    <?php echo e("Private"); ?>

                                    <?php else: ?>
                                    <?php echo e("Published"); ?>

                                    <?php endif; ?>
                                </div>
                                <h3 class="head">Hot:</h3>
                                <div>
                                    <?php if($tour->is_hot == 0): ?>
                                    <?php echo e("Not hot"); ?>

                                    <?php else: ?>
                                    <?php echo e("Hot"); ?>

                                    <?php endif; ?>
                                </div>
                                <h3 class="head">Meta key:</h3>
                                <div><?php echo e($tour->meta_key); ?></div>
                                <h3 class="head">Name Seo:</h3>
                                <div><?php echo e($tour->name_seo); ?></div>
                                <h3 class="head">Tag:</h3>
                                <div><?php echo e($tour->tag); ?></div>
                                <h3 class="head">Author:</h3>
                                <div><?php echo e($tour->user->name); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>