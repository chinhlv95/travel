<div class="destination">
  <?php for( $i=0; $i<count($dataCategories); $i++ ): ?>
  <div class=" col-sm-6">
      <div class="foot-header">
        <?php echo e($dataCategories[$i]['name']); ?>

      </div>
      <div class="foot-links">
        <?php for( $j=0; $j<count($dataDestination); $j++ ): ?>
          <?php if( $dataDestination[$j]['cate_id'] == $dataCategories[$i]['id'] ): ?>
          <a href="<?php echo e(URL::to('/')); ?>/destination/<?php echo e($dataDestination[$j]['id']); ?>"><?php echo e($dataDestination[$j]['name']); ?></a>
          <?php endif; ?>
        <?php endfor; ?>
      </div>
  </div><!--/ col-sm-6-->
  <?php endfor; ?>
</div>