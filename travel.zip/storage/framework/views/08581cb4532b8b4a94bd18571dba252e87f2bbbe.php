<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('content'); ?>

<section class="check-code">
  <div class="container">
    <?php if(empty($dataCodeOrder)): ?>
    <div class="row breadcrumb-detail">
     <ol class="breadcrumb">
      <li><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
      <li class="active">Kiểm tra tour</li>        
    </ol>
  </div>
  <?php echo e("Mã đặt tour không tồn tại !"); ?>

  <div id="fix-height"></div>
  <?php else: ?>
  <div class="row breadcrumb-detail">
   <ol class="breadcrumb">
    <li><a href="#">Home</a></li>
    <li class="active">Kiểm tra tour</li>        
  </ol>
</div>
<div class="tour-sale-title">
 <h2><a href="">THÔNG TIN TOUR ĐÃ ĐẶT</a></h2>
 <p class="tour-sale-line"></p>
</div>
<div class="info-order">
  <div class="row">
   <div class="col-md-6">
    <div class="info-order-tour" >
      <div class="info-tour-title">
        <h4>Thông tin tour</h4>
      </div>
      <div class="row">
       <div class="col-md-6">
        <div id="checkout-image-tour">
         <img src="<?php echo e($dataCodeOrder->image); ?>" alt="<?php echo e($dataCodeOrder->image); ?>">
       </div>
     </div>
     <div class="col-md-6">
      <div id="checkout-info-tour">
       <p><span class="first-name-tour">Tour:</span> <span><?php echo e($dataCodeOrder->name); ?></span></p>
       <p><span class="first-name-tour">Ngày khởi hành:</span><span><?php echo e(date('d-m-Y', strtotime($dataCodeOrder->start_date))); ?></span></p>
       <p><span class="first-name-tour">Số lượng:</span><span><?php echo e($dataCodeOrder->booked); ?>(người)</span></p>
       <p><span class="first-name-tour">Giá:</span><?php echo e(number_format((int)($dataCodeOrder->price)*(1-(int)($dataSale->sale_precent)/100))."đ"); ?>  </p>
     </div>
   </div>
 </div>
</div>
</div>
<div class="col-md-6">
  <div class="info-order-customer">
    <div class="info-tour-title">
      <h4>Thông tin người đặt tour</h4>
    </div>
    <div id="info-order-customer-checkout">
      <p><span class="first-name-tour">Họ tên:</span><span><?php echo e($dataCodeOrder->fullname); ?></span></p>
      <p><span class="first-name-tour">Email:</span><span><?php echo e($dataCodeOrder->email); ?></span></p>
      <p><span class="first-name-tour">SĐT:</span><span><?php echo e($dataCodeOrder->phone); ?></span></p>
      <p><span class="first-name-tour">Ngày sinh:</span><span><?php echo e(date('d-m-Y', strtotime($dataCodeOrder->birthday))); ?></span></p>
      <p><span class="first-name-tour">Giới tính:</span><span><?php echo e(($dataCodeOrder->gender)?"Nam":"Nữ"); ?></span></p>
      <p><span class="first-name-tour">Địa chỉ:</span><span><?php echo e($dataCodeOrder->address); ?></span></p>
      <p><span class="first-name-tour">Ghi chú:</span><span><?php echo e($dataCodeOrder->note); ?></span></p>
    </div>
  </div>
</div>
</div>
</div>
<div class="list-tourers">
  <div class="info-tour-title-list">
    <h4>Danh sách người trong tour</h4>
  </div>
  <table class="table table-striped table-bordered ">
    <thead>
      <th class="header-list-tourer"></th>
      <th class="header-list-tourer">Họ Tên</th>
      <th class="header-list-tourer">Ngày sinh</th>
      <th class="header-list-tourer">Giới tính</th>
      <th class="header-list-tourer">Điện thoại</th>
      <th class="header-list-tourer">Địa chỉ</th>
    </thead>
    <tbody>
      <?php $i=1; 
      $total=0;
      ?>
      <?php $__currentLoopData = $dataTourerList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($i); ?></td>
        <td><?php echo e($value->fullname); ?></td>
        <td><?php echo e(date('d-m-Y', strtotime($value->birthday))); ?></td>
        <td><?php echo e(($value->gender)?"Nam":"Nữ"); ?></td>
        <td><?php echo e($value->phone); ?></td>
        <td><?php echo e($value->address); ?></td>
        
      </tr>
      <?php 
      $total+=(int)($dataCodeOrder->price)*(1-(int)($dataSale->sale_precent)/100);
      $i++; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      
      <tr>
        <td colspan="5">
          Tổng tiền
        </td>
        <td><?php echo e($total."đ"); ?></td>
      </tr>
    </tbody>
  </table>
</div>
<?php endif; ?>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>