<?php

namespace App\Repositories\Traffic;

interface TrafficRepositoryInterface
{

}