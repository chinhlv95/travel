<?php

namespace App\Repositories\Pay;

interface PayRepositoryInterface
{

}