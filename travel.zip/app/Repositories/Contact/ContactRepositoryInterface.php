<?php

namespace App\Repositories\Contact;

interface ContactRepositoryInterface
{

}