<?php

namespace App\Repositories\Province;

interface ProvinceRepositoryInterface
{

}