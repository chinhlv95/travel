<?php

namespace App\Repositories\PriceRange;

interface PriceRangeRepositoryInterface
{

}