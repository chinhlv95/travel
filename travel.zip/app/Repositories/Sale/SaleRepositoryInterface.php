<?php

namespace App\Repositories\Sale;

interface SaleRepositoryInterface
{

}